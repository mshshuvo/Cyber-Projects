Exported for year-end reconciliation. Delete after audit.
